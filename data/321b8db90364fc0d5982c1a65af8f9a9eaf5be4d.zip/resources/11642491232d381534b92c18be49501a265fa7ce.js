AOS.init({duration: 1000, delay: 200});

// Add active class to nav-link
const currentLocation = location.href;
const menuItem = document.querySelectorAll('.nav-link');
console.log(currentLocation + menuItem)
for (let index = 0; index < menuItem.length; index++) {
if (menuItem[index].href === currentLocation) {
menuItem[index].className = "nav-link active";
}
};
function e(e){return e.charAt(0).toUpperCase()+e.slice(1)}export{e as c};

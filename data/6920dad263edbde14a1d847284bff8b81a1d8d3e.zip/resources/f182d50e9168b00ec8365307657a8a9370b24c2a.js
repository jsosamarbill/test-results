/*--------------------------------------------------
Template Name: fondle ;
Description: pet shop, pet shitter, pet food, pet care bootstrap 5 Template
Version: 1.0;

NOTE: main.js, All custom script and plugin activation script in this file. 

----------------------------------------------------*/

(function($) {
    "use Strict";

    /*---------------------------
    1. Newsletter Popup
    ----------------------------*/
    setTimeout(function() {
        $('.popup_wrapper').css({
            "opacity": "1",
            "visibility": "visible"
        });
        $('.popup_off').on('click', function() {
            $(".popup_wrapper").fadeOut(500);
        })
    }, 2500);

    /*----------------------------
    2. Mobile Menu Activation
    -----------------------------*/
    jQuery('.mobile-menu nav').meanmenu({
        meanScreenWidth: "991",
    });

    /*----------------------------
    3. Tooltip Activation
    ------------------------------ */
	/*
    $('.item_add_cart a,.item_quick_link a').tooltip({
        animated: 'fade',
        placement: 'top',
        container: 'body'
    });*/

    /*---------------------------------
	4. Cart Box Dropdown Menu 
    -----------------------------------*/
    $('.drodown-show > a').on('click', function(e) {
        e.preventDefault();
        if ($(this).hasClass('active')) {
            $('.drodown-show > a').removeClass('active').siblings('.dropdown').slideUp()
            $(this).removeClass('active').siblings('.dropdown').slideUp();
        } else {
            $('.drodown-show > a').removeClass('active').siblings('.dropdown').slideUp()
            $(this).addClass('active').siblings('.dropdown').slideDown();
        }
    });

    /*----------------------------
    5. Checkout Page Activation
    -----------------------------*/
    $('#showlogin').on('click', function() {
        $('#checkout-login').slideToggle();
    });
    $('#showcoupon').on('click', function() {
        $('#checkout_coupon').slideToggle();
    });
    $('#cbox').on('click', function() {
        $('#cbox_info').slideToggle();
    });
    $('#ship-box').on('click', function() {
        $('#ship-box-info').slideToggle();
    });



    /*--------------------------
        Product Zoom
	---------------------------- */
    $(".zoompro").elevateZoom({
        gallery: "gallery",
        galleryActiveClass: "active",
        zoomWindowWidth: 300,
        zoomWindowHeight: 100,
        scrollZoom: false,
        zoomType: "inner",
        cursor: "crosshair"
    });


    /*----------------------------
    16. ScrollUp Activation
    -----------------------------*/
    $.scrollUp({
        scrollName: 'scrollUp', // Element ID
        topDistance: '550', // Distance from top before showing element (px)
        topSpeed: 1000, // Speed back to top (ms)
        animation: 'fade', // Fade, slide, none
        scrollSpeed: 900,
        animationInSpeed: 1000, // Animation in speed (ms)
        animationOutSpeed: 1000, // Animation out speed (ms)
        scrollText: '<i class="icofont-long-arrow-up"></i>', // Text for element
        activeOverlay: false // Set CSS color to display scrollUp active point, e.g '#00FFFF'
    });

    /*----------------------------
    17. Sticky-Menu Activation
    ------------------------------ */
    $(window).on('scroll', function() {
        if ($(this).scrollTop() > 100) {
            $('.header-sticky').addClass("sticky");
        } else {
            $('.header-sticky').removeClass("sticky");
        }
    });

    /*----------------------------
    18. Nice Select Activation
    ------------------------------ */
    $('select').niceSelect();

    /*----------------------------
    19. Price Slider Activation
    -----------------------------*/
    $("#slider-range").slider({
        range: true,
        min: 0,
        max: 100,
        values: [0, 85],
        slide: function(event, ui) {
            $("#amount").val("$" + ui.values[0] + "  $" + ui.values[1]);
        }
    });
    $("#amount").val("$" + $("#slider-range").slider("values", 0) +
        "  $" + $("#slider-range").slider("values", 1));


    /*----------------------------
    15. Countdown Js Activation
    -----------------------------*/
    $('[data-countdown]').each(function() {
        var $this = $(this),
            finalDate = $(this).data('countdown');
        $this.countdown(finalDate, function(event) {
            $this.html(event.strftime('<div class="count"><p>%D</p><span>Days</span></div><div class="count"><p>%H</p> <span>Hours</span></div><div class="count"><p>%M</p> <span>Mins</span></div><div class="count"> <p>%S</p> <span>Secs</span></div>'));
        });
    });

    /*----------------------------
    16. Product Varient
    -----------------------------*/
    $('.grid_color_image li .variant_img').on('click', function() {
        var variantImage = jQuery(this).parent().find('.variant_img a img').attr('src');
        jQuery(this).parents('.single-template-product').find('.pro-img a img.primary-img').attr({ src: variantImage });
        return false;
    });

    //$('.variant_img a').addClass('active');

    $('.grid_color_image li .variant_img a').on('click', function() {
        $('.grid_color_image li .variant_img a.active').removeClass('active');
        $(this).addClass('active');
    });



    /* =========Portfolio Active =============*/
    var isotopFilter = $('.portfolio-filters');
    var isotopGrid = $('.portfolios:not(.portfolios-slider-active)');
    var isotopGridItemSelector = $('.portfolio-single');
    var isotopGridItem = '.portfolio-single';

    isotopFilter.find('button:first-child').addClass('active');

    //Images Loaded
    isotopGrid.imagesLoaded(function() {
        /*-- init Isotope --*/
        var initial_items = isotopGrid.data('show');
        var next_items = isotopGrid.data('load');
        var loadMoreBtn = $('.load-more-toggle');

        var $grid = isotopGrid.isotope({
            itemSelector: isotopGridItem,
            layoutMode: 'masonry',
        });

        /*-- Isotop Filter Menu --*/
        isotopFilter.on('click', 'button', function() {
            var filterValue = $(this).attr('data-filter');

            isotopFilter.find('button').removeClass('is-checked');
            $(this).addClass('is-checked');

            // use filterFn if matches value
            $grid.isotope({
                filter: filterValue
            });
        });


    });



    /*---------------------
        Video popup
    --------------------- */
    $('.video-popup').magnificPopup({
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        zoom: {
            enabled: true,
        }
    });

    /*--
    Magnific Popup
    ------------------------*/
    $('.img-popup').magnificPopup({
        type: 'image',
        gallery: {
            enabled: true
        }
    });


    /*--
    Magnific Popup
    ------------------------*/
    $('.img-popup-2').magnificPopup({
        type: 'image',
        gallery: {
            enabled: true
        }
    });


    /*--------------------------
    tab active
    ---------------------------- */
    var ProductDetailsSmall = $('.product-details-small a');

    ProductDetailsSmall.on('click', function(e) {
        e.preventDefault();

        var $href = $(this).attr('href');

        ProductDetailsSmall.removeClass('active');
        $(this).addClass('active');

        $('.product-details-large .tab-pane').removeClass('active');
        $('.product-details-large ' + $href).addClass('active');
    })


    /*--- Clickable menu active ----*/
    const slinky = $('#menu').slinky()

    /*====== sidebarCart ======*/
    function sidebarMainmenu() {
        var menuTrigger = $('.clickable-mainmenu-active'),
            endTrigger = $('button.clickable-mainmenu-close'),
            container = $('.clickable-mainmenu');
        menuTrigger.on('click', function(e) {
            e.preventDefault();
            container.addClass('inside');
        });
        endTrigger.on('click', function() {
            container.removeClass('inside');
        });
    };
    sidebarMainmenu();



    /*---------------------
        Sidebar active
    --------------------- */
    $('.sidebar-active').stickySidebar({
        topSpacing: 80,
        bottomSpacing: 30,
        minWidth: 767,
    });





})(jQuery);